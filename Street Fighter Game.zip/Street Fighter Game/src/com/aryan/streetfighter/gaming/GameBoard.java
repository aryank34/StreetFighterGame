package com.aryan.streetfighter.gaming;

import com.aryan.streetfighter.sprites.Health;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.aryan.streetfighter.sprites.OpponentPlayer;
import com.aryan.streetfighter.sprites.Player;
import com.aryan.streetfighter.sprites.PowerEffect;
import com.aryan.streetfighter.utils.GameConstants;
import static com.aryan.streetfighter.utils.GameConstants.JUMP;
import static com.aryan.streetfighter.utils.GameConstants.KICK;
import static com.aryan.streetfighter.utils.GameConstants.WALK;
import jaco.mp3.player.MP3Player;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.Timer;

public class GameBoard extends JPanel implements GameConstants {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    BufferedImage bgImage;
    private Player player;
    private OpponentPlayer oppPlayer;
    private Timer timer;
    private Health ken_health;
    private Health derek_health;
    private boolean isGameOver;
    private String winner;
    private MP3Player mp3player;
    
    public GameBoard() {
        player = new Player();
        oppPlayer = new OpponentPlayer();

        setFocusable(true);
        loadBackground();
        bindEvents();
        loadHealth();
        loadMusic();
        gameLoop();
    }

    private void gameLoop() {
        timer = new Timer(180, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                repaint();
                player.fall();
                oppPlayer.fall();
                collision();
            }
        });
        timer.start();
    }
    
    private void loadHealth(){
        ken_health = new Health(40,"KEN");
        derek_health = new Health(SCREENWIDTH - 550, "DEREK");
    }
    
    private void printHealth(Graphics pen){
        ken_health.printHealth(pen);
        derek_health.printHealth(pen);
    }

    private boolean isCollide() {
        int xDistance = Math.abs(player.getX() - oppPlayer.getX());
        int yDistance = Math.abs(player.getY() - oppPlayer.getY());
        int maxH = Math.max(player.getH(), oppPlayer.getH());
        int maxW = Math.max(player.getW(), oppPlayer.getW());

        return xDistance <= maxW && yDistance <= maxH;
    }

    private void collision() {
        if (isCollide()) {
            if (player.isIsAttacking() && oppPlayer.isIsAttacking()) {
                //both are attacking at the same time
                oppPlayer.setCurrentMove(HIT);
                derek_health.setHealth();
                player.setCurrentMove(HIT);
                ken_health.setHealth();
            } else if (player.isIsAttacking()) {
                oppPlayer.setCurrentMove(HIT);
                //oppPlayer decrease health
                derek_health.setHealth();
            } else if (oppPlayer.isIsAttacking()) {
                player.setCurrentMove(HIT);
                //player decrease health
                ken_health.setHealth();
            }
            
            if(derek_health.getHealth()<=0 || ken_health.getHealth() <= 0){
                if(ken_health.getHealth()>0){
                    winner = "KEN";
                }else{
                    winner = "DEREK";
                }
                isGameOver=true;
            }

            player.setIsCollide(true);
            oppPlayer.setIsCollide(true);
            player.setSpeed(0);
            oppPlayer.setSpeed(0);
        } else {
            player.setIsCollide(false);
            oppPlayer.setIsCollide(false);
            player.setSpeed(SPEED);
            oppPlayer.setSpeed(SPEED);
        }
    }
    
    private void printGameOver(Graphics pen){
        pen.setColor(Color.WHITE);
        pen.setFont(new Font("times",Font.BOLD,80));
        pen.drawString("GAME OVER", SCREENWIDTH/2-280, SCREENHEIGHT/2-40);
        printWinner(pen);
    }
    
    private void printWinner(Graphics pen){
        pen.setColor(Color.RED);
        pen.setFont(new Font("times",Font.BOLD,80));
        pen.drawString("Winner: "+winner, SCREENWIDTH/2-300, SCREENHEIGHT/2+30);
    }

    @Override
    public void paintComponent(Graphics pen) {
        //Displays any text in the console
        paintBackground(pen);
        player.paintPlayer(pen);
        oppPlayer.paintPlayer(pen);
        setFocusable(true);//to keep the focus on the code and ignore the behind scenes console
        bindEvents();
        printHealth(pen);
        printPower(pen);
        if(isGameOver == true){
            printGameOver(pen);
            timer.stop();
            mp3player.stop();
        }
    }

    private void paintBackground(Graphics pen) {
        //this method will display the images

        //display the image
        pen.drawImage(bgImage, 0, 0, SCREENWIDTH, SCREENHEIGHT, null);

        //set color of the pen
//        pen.setColor(Color.GREEN);
//        //draw rectangle
//        pen.fillRect(100, 10, 400, 40);
//        pen.fillRect(680, 10, 400, 40);

    }

    //whenever a key is pressed, it binds/combines it with an event/action
    void bindEvents() {
        //Key Listener is an interface
        // we can't create its object, so we use anonymous classes to implement that method
        this.addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {
                //System.out.println("Key Typed: "+e.getKeyCode());

            }

            @Override
            public void keyReleased(KeyEvent e) {
                //System.out.println("Key Released: "+e.getKeyCode());
                player.setSpeed(0);
            }

            @Override
            public void keyPressed(KeyEvent e) {
                //write action for the keyboard keys to be pressed
                //System.out.println("Key Pressed "+e.getKeyCode());

                //Main Player
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    player.setSpeed(-SPEED);
                    if (player.getX() >= 0) {
                        player.move();
                    }
                    player.setIsCollide(false);
                    player.setCurrentMove(WALK);
                    //repaint();
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    player.setSpeed(SPEED);
                    if (player.getX() + player.getW() <= oppPlayer.getX() + 15) {
                        player.move();
                    }
                    player.setCurrentMove(WALK);
                    //repaint();
                } else if (e.getKeyCode() == KeyEvent.VK_M) {
                    player.setCurrentMove(PUNCH);
                    player.setIsAttacking(true);
                } else if (e.getKeyCode() == KeyEvent.VK_N) {
                    player.setCurrentMove(KICK);
                    player.setIsAttacking(true);
                } else if (e.getKeyCode() == KeyEvent.VK_UP) {
                    player.setCurrentMove(JUMP);
                    player.jump();
                } else if(e.getKeyCode() == KeyEvent.VK_SPACE){
                    player.setCurrentMove(POWER);
                    player.showPower();
                }

                //Opponent player
                if (e.getKeyCode() == KeyEvent.VK_A) {
                    oppPlayer.setSpeed(-SPEED);
                    if (oppPlayer.getX() + 15 >= player.getX() + player.getW()) {
                        oppPlayer.move();
                    }
                    oppPlayer.setCurrentMove(WALK);
                    //repaint();
                } else if (e.getKeyCode() == KeyEvent.VK_D) {
                    oppPlayer.setSpeed(SPEED);
                    if (oppPlayer.getX() + oppPlayer.getW() <= SCREENWIDTH) {
                        oppPlayer.move();
                    }
                    oppPlayer.setIsCollide(false);
                    oppPlayer.setCurrentMove(WALK);
                    //repaint();
                } else if (e.getKeyCode() == KeyEvent.VK_V) {
                    oppPlayer.setCurrentMove(PUNCH);
                    oppPlayer.setIsAttacking(true);
                } else if (e.getKeyCode() == KeyEvent.VK_C) {
                    oppPlayer.setCurrentMove(KICK);
                    oppPlayer.setIsAttacking(true);
                } else if (e.getKeyCode() == KeyEvent.VK_W) {
                    oppPlayer.setCurrentMove(JUMP);
                    oppPlayer.jump();
                }
            }
        });
    }
    
    private void printPower(Graphics pen){
        for(PowerEffect power : player.getPowers()){
            power.printPower(pen);
        }
    }
    
    private void loadMusic(){
        mp3player = new MP3Player(GameBoard.class.getResource("theme.mp3"));
        mp3player.play();
    }

    private void loadBackground() {
        //this method will load images into our java program
        try {
            bgImage = ImageIO.read(GameBoard.class.getResource(BG_IMG));
        } catch (Exception e) {
            //System.out.println("Failed to load the background Image...");
            JOptionPane.showMessageDialog(this, "Failed to load Background Image...");
            System.exit(0);
        }
    }
}
