package com.aryan.streetfighter.gaming;

import javax.swing.JFrame;

import com.aryan.streetfighter.utils.GameConstants;

public class GameScreen extends JFrame implements GameConstants {

    public GameScreen() {
        setResizable(false); //cant maximise or minimise the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(SCREENWIDTH, SCREENHEIGHT);
        setLocationRelativeTo(null); //to open the screen in the centre of laptop screen, centres of frame and screen coincide
        setTitle(TITLE);
        GameBoard board = new GameBoard();
        add(board);
        setVisible(true);
    }
}
