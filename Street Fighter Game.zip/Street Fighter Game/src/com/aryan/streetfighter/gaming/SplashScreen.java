package com.aryan.streetfighter.gaming;

import com.aryan.streetfighter.utils.GameConstants;
import static com.aryan.streetfighter.utils.GameConstants.SCREENHEIGHT;
import static com.aryan.streetfighter.utils.GameConstants.SCREENWIDTH;
import static com.aryan.streetfighter.utils.GameConstants.TITLE;
import javax.swing.*;

public class SplashScreen extends JFrame implements GameConstants{
    private JLabel label = new JLabel();
    public SplashScreen(){
        Icon icon = new ImageIcon(SplashScreen.class.getResource("splash screen image.jpg"));
        label.setIcon(icon);
        this.add(label);
        setResizable(false); //cant maximise or minimise the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(SCREENWIDTH, SCREENHEIGHT);
        setLocationRelativeTo(null); //to open the screen in the centre of laptop screen, centres of frame and screen coincide
        setTitle(TITLE);
        setVisible(true);
        try{
            Thread.sleep(10000);
            setVisible(false);//splash screen will close and will not be visible
            dispose();
            GameScreen obj = new GameScreen();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        SplashScreen screen = new SplashScreen();
    }
}
