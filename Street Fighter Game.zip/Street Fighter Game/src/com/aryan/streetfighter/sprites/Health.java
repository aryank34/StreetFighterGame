package com.aryan.streetfighter.sprites;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Health extends CommonPlayer{
    Color color;
    String playerName;
    public Health(int x, String playerName){
        this.x = x;
        y = 20;
        w = MAX_HEALTH;
        h = 50;
        this.playerName = playerName;
        health = MAX_HEALTH;
    }

    public void setHealth(){
        if(health > 0){
            health = health - (int)(MAX_HEALTH *0.05);//5% decrease
        }
    }
    
    public void printHealth(Graphics pen){
        //red rectangle
        pen.setColor(Color.RED);
        pen.fillRect(x, y, w, h);
        //green rectangle over the red one
        pen.setColor(Color.GREEN);
        pen.fillRect(x, y, health, h);
        
        //display the names of the players
        pen.setColor(Color.WHITE);
        pen.setFont(new Font("times",Font.BOLD, 50));
        pen.drawString(playerName, x, y+h+40);
    }
    
    @Override
    public BufferedImage defaultImage() {
        return null;
    }
}
