package com.aryan.streetfighter.sprites;

import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.aryan.streetfighter.utils.GameConstants;

public class OpponentPlayer extends CommonPlayer implements GameConstants {

    private BufferedImage idleImages[] = new BufferedImage[2];
    private BufferedImage walkImages[] = new BufferedImage[3];
    private BufferedImage punchImages[] = new BufferedImage[4];
    private BufferedImage kickImages[] = new BufferedImage[3];
    private BufferedImage jumpImages[] = new BufferedImage[3];
    private BufferedImage hitImages[] = new BufferedImage[2];
    private int force;
    private int temp = 400;

    public OpponentPlayer() {
        x = SCREENWIDTH - 400;
        y = GROUND;
        w = 90;
        h = 130;
        speed = 0;
        try {
            playerImg = ImageIO.read(Player.class.getResource(DEREK_IMAGE));
        } catch (Exception e) {
            System.out.println("Failed to load PLayer Image...");
        }
        loadIdleImages();
        loadWalkImages();
        loadPunchImages();
        loadKickImages();
        loadJumpImages();
        loadHitImages();
    }

    public void jump() {
        force = -10;
        y = temp;

    }

    public void fall() {
        if (y + force >= GROUND) {
            y = GROUND;
            return;
        }
        force = force + GRAVITY;
        y = y + force;
    }

    private void loadHitImages() {
        hitImages[0] = playerImg.getSubimage(101, 301, 46, 67);
        hitImages[1] = playerImg.getSubimage(501, 78, 38, 65);
    }

    public BufferedImage printHit() {
        isAttacking = false;
        if (imageIndex > 1) {
            imageIndex = 0;
            currentMove = IDLE;
        }
        BufferedImage img = hitImages[imageIndex];
        imageIndex++;
        return img;
    }

    private void loadIdleImages() {
        idleImages[0] = playerImg.getSubimage(520, 297, 48, 71);
        //idleImages[1] = playerImg.getSubimage(579, 298, 49, 70);
        idleImages[1] = playerImg.getSubimage(462, 298, 50, 69);
    }

    public BufferedImage printIdle() {
        isAttacking = false;
        if (imageIndex > 1) {
            imageIndex = 0;
        }
        BufferedImage img = idleImages[imageIndex];
        imageIndex++;
        return img;
    }

    private void loadWalkImages() {
        walkImages[0] = playerImg.getSubimage(462, 298, 50, 69);
        walkImages[1] = playerImg.getSubimage(160, 305, 46, 63);
        walkImages[2] = playerImg.getSubimage(522, 297, 48, 70);
    }

    public BufferedImage printWalk() {
        isAttacking = false;
        if (imageIndex > 2) {
            imageIndex = 0;
            currentMove = IDLE;
        }
        BufferedImage img = walkImages[imageIndex];
        imageIndex++;
        return img;
    }

    private void loadPunchImages() {
        punchImages[0] = playerImg.getSubimage(556, 154, 73, 68);
        punchImages[1] = playerImg.getSubimage(99, 7, 40, 61);
        punchImages[2] = playerImg.getSubimage(160, 302, 45, 66);
        punchImages[3] = playerImg.getSubimage(219, 299, 45, 66);
    }

    public BufferedImage printPunch() {
        isAttacking = true;
        if (imageIndex > 3) {
            imageIndex = 0;
            currentMove = IDLE;
            isAttacking = false;
        }
        BufferedImage img = punchImages[imageIndex];
        imageIndex++;
        return img;
    }

    private void loadJumpImages() {
        jumpImages[0] = playerImg.getSubimage(217, 165, 43, 49);
        jumpImages[1] = playerImg.getSubimage(42, 15, 43, 47);
        jumpImages[2] = playerImg.getSubimage(96, 6, 43, 64);
    }

    public BufferedImage printJump() {
        isAttacking = false;
        if (imageIndex > 2) {
            imageIndex = 0;
            currentMove = IDLE;
        }
        BufferedImage img = jumpImages[imageIndex];
        imageIndex++;
        return img;
    }

    private void loadKickImages() {
        kickImages[0] = playerImg.getSubimage(500, 79, 40, 64);
        kickImages[1] = playerImg.getSubimage(434, 78, 44, 68);
        kickImages[2] = playerImg.getSubimage(320, 81, 44, 68);
    }

    public BufferedImage printKick() {
        isAttacking = true;
        if (imageIndex > 2) {
            imageIndex = 0;
            currentMove = IDLE;
            isAttacking = false;
        }
        BufferedImage img = kickImages[imageIndex];
        imageIndex++;
        return img;
    }

    @Override
    public BufferedImage defaultImage() {
        //derek's default image :- X = 523 Y = 294  Width = 47 Height = 74
        //return playerImg.getSubimage(523, 294, 47, 74);
        if (currentMove == WALK) {
            return printWalk();
        } else if (currentMove == PUNCH) {
            return printPunch();
        } else if (currentMove == KICK) {
            return printKick();
        } else if (currentMove == JUMP) {
            return printJump();
        } else if (currentMove == HIT) {
            return printHit();
        } else {
            return printIdle();
        }
    }
}
