package com.aryan.streetfighter.sprites;

import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.aryan.streetfighter.utils.GameConstants;
import java.util.ArrayList;

public class Player extends CommonPlayer implements GameConstants {

    private BufferedImage idleImages[] = new BufferedImage[2];
    private BufferedImage walkImages[] = new BufferedImage[4];
    private BufferedImage punchImages[] = new BufferedImage[3];
    private BufferedImage kickImages[] = new BufferedImage[3];
    private BufferedImage jumpImages[] = new BufferedImage[3];
    private BufferedImage hitImages[] = new BufferedImage[2];
    private BufferedImage powerImages[] = new BufferedImage[3];
    private int force;
    private int temp = 400;

    public Player() {
        x = 250;
        y = GROUND;
        w = 90;
        h = 130;
        speed = 0;
        force = 0;
        try {
            playerImg = ImageIO.read(Player.class.getResource(KEN_IMAGE));
            playerPowerImg = ImageIO.read(Player.class.getResource(KEN_POWER_IMAGE));
        } catch (Exception e) {
            System.out.println("Failed to load PLayer Image...");
        }
        loadIdleImages();
        loadWalkImages();
        loadPunchImages();
        loadKickImages();
        loadJumpImages();
        loadHitImages();
        loadPowerImages();
    }

    public void jump() {
        force = -10;
        y = temp;

    }

    public void fall() {
        if (y + force >= GROUND) {
            y = GROUND;
            return;
        }
        force = force + GRAVITY;
        y = y + force;
    }
    
    private void loadPowerImages() {
        powerImages[0] = playerImg.getSubimage(215, 363, 39, 58);
        powerImages[1] = playerImg.getSubimage(320, 363, 39, 58);
        powerImages[2] = playerImg.getSubimage(262, 362, 51, 58);
    }
    
    public BufferedImage printPower() {
        isAttacking = false;
        if (imageIndex > 2) {
            imageIndex = 0;
            currentMove = IDLE;
        }
        BufferedImage img = powerImages[imageIndex];
        imageIndex++;
        return img;
    }
    private ArrayList<PowerEffect> powers = new ArrayList<>();
    
    public ArrayList<PowerEffect> getPowers(){
        return powers;
    }
    
    public void showPower(){
        powers.add(new PowerEffect(x+w-40, y+h/2-50, playerPowerImg));
    }

    private void loadHitImages() {
        hitImages[0] = playerImg.getSubimage(49, 506, 35, 58);
        hitImages[1] = playerImg.getSubimage(4, 506, 39, 58);
    }

    public BufferedImage printHit() {
        isAttacking = false;
        if (imageIndex > 1) {
            imageIndex = 0;
            currentMove = IDLE;
        }
        BufferedImage img = hitImages[imageIndex];
        imageIndex++;
        return img;
    }
    
    private void loadIdleImages() {
        idleImages[0] = playerImg.getSubimage(275, 503, 33, 59);
        //idleImages[1] = playerImg.getSubimage(236, 500, 33, 65);
        idleImages[1] = playerImg.getSubimage(315, 501, 33, 61);
    }

    public BufferedImage printIdle() {
        isAttacking = false;
        if (imageIndex > 1) {
            imageIndex = 0;
        }
        BufferedImage img = idleImages[imageIndex];
        imageIndex++;
        return img;
    }

    private void loadWalkImages() {
        walkImages[0] = playerImg.getSubimage(0, 5, 33, 61);
        walkImages[1] = playerImg.getSubimage(27, 5, 33, 61);
        walkImages[2] = playerImg.getSubimage(66, 5, 33, 61);
        walkImages[3] = playerImg.getSubimage(100, 3, 26, 61);
        //walkImages[4] = playerImg.getSubimage(132, 3, 26, 61);
    }

    public BufferedImage printWalk() {
        isAttacking = false;
        if (imageIndex > 3) {
            imageIndex = 0;
            currentMove = IDLE;
        }
        BufferedImage img = walkImages[imageIndex];
        imageIndex++;
        return img;
    }

    private void loadPunchImages() {
        punchImages[0] = playerImg.getSubimage(4, 187, 39, 61);
        punchImages[1] = playerImg.getSubimage(48, 187, 48, 61);
        punchImages[2] = playerImg.getSubimage(101, 189, 61, 61);
    }

    public BufferedImage printPunch() {
        isAttacking = true;
        if (imageIndex > 2) {
            imageIndex = 0;
            currentMove = IDLE;
            isAttacking = false;
        }
        BufferedImage img = punchImages[imageIndex];
        imageIndex++;
        return img;
    }

    private void loadJumpImages() {
        jumpImages[0] = playerImg.getSubimage(234, 88, 29, 41);
        jumpImages[1] = playerImg.getSubimage(264, 87, 31, 41);
        jumpImages[2] = playerImg.getSubimage(297, 88, 31, 41);
    }

    public BufferedImage printJump() {
        isAttacking = false;
        if (imageIndex > 2) {
            imageIndex = 0;
            currentMove = IDLE;
        }
        BufferedImage img = jumpImages[imageIndex];
        imageIndex++;
        return img;
    }

    private void loadKickImages() {
        kickImages[0] = playerImg.getSubimage(160, 253, 31, 60);
        kickImages[1] = playerImg.getSubimage(121, 252, 38, 60);
        kickImages[2] = playerImg.getSubimage(61, 256, 60, 60);
    }

    public BufferedImage printKick() {
        isAttacking = true;
        if (imageIndex > 2) {
            imageIndex = 0;
            currentMove = IDLE;
            isAttacking = false;
        }
        BufferedImage img = kickImages[imageIndex];
        imageIndex++;
        return img;
    }

    @Override
    public BufferedImage defaultImage() {
        //ken's default image :- X = 237 Y = 500 Width = 35 Height = 64
        //return playerImg.getSubimage(237, 500, 35, 64);
        if (currentMove == WALK) {
            return printWalk();
        } else if (currentMove == PUNCH) {
            return printPunch();
        } else if (currentMove == KICK) {
            return printKick();
        } else if (currentMove == JUMP) {
            return printJump();
        } else if (currentMove == HIT) {
            return printHit();
        } else if(currentMove == POWER){
            return printPower();
        } 
        else {
            return printIdle();
        }
    }
}
