package com.aryan.streetfighter.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class PowerEffect extends CommonPlayer {

    public PowerEffect(int x, int y, BufferedImage img) {
        OpponentPlayer opp = new OpponentPlayer();
        this.playerPowerImg = img;
        this.x = x;
        this.y = y;
        w = 50;
        h = 50;
        speed = 70;
    }

    @Override
    public BufferedImage defaultImage() {
        return playerPowerImg.getSubimage(9, 338, 33, 27);
    }

    public void printPower(Graphics pen) {
        pen.drawImage(defaultImage(), x, y, w, h, null);
        move();
    }
}
