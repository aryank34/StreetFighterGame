package com.aryan.streetfighter.utils;

import jdk.nashorn.internal.runtime.regexp.joni.Config;

public interface GameConstants {

    String TITLE = ConfigReader.getValue("game.title");
    int SCREENWIDTH = Integer.parseInt(ConfigReader.getValue("game.width"));
    int SCREENHEIGHT = Integer.parseInt(ConfigReader.getValue("game.height"));
    int GROUND = Integer.parseInt(ConfigReader.getValue("game.height")) - 210;
    String DEREK_IMAGE = ConfigReader.getValue("oppPlayer.img");
    String KEN_IMAGE = ConfigReader.getValue("player.img");
    String KEN_POWER_IMAGE = ConfigReader.getValue("playerPower.img");
    String BG_IMG = ConfigReader.getValue("bg.img");
    int SPEED = 1;
    int IDLE = 1;
    int WALK = 2;
    int KICK = 3;
    int PUNCH = 4;
    int JUMP = 5;
    int HIT = 6;
    int POWER = 7;
    
    int MAX_HEALTH = 500;
    
    int GRAVITY = 10;
}
